<?php
require '../config.php';

$id   = (int)($_POST['id'] ?? 0);
$type =         $_POST['type'] ?? 'unban';   // ban24 | ban7 | ban30 | banForever | unban

if (!$id) {
    http_response_code(400);
    exit('ERR');
}

switch ($type) {
    case 'ban24':      $until = date('Y-m-d H:i:s', strtotime('+24 hours')); break;
    case 'ban7':       $until = date('Y-m-d H:i:s', strtotime('+7 days'));   break;
    case 'ban30':      $until = date('Y-m-d H:i:s', strtotime('+30 days'));  break;
    case 'banForever': $until = '9999-12-31 23:59:59';                       break;
    default:           $until = null;                                        break; // un-ban
}

$pdo->prepare("UPDATE users SET banned_until = ? WHERE telegram_id = ?")
    ->execute([$until, $id]);

echo 'OK';
