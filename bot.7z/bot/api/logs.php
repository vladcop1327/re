<?php
require '../config.php';

/*
 * GET page = 1…N
 * -------------------------------------------------------
 * {
 *   rows:[{
 *       code,
 *       used_by,
 *       used_by_username,
 *       used_by_phone,
 *       used_at,
 *       segment_label
 *   }, …],
 *   hasMore:true|false
 * }
 */

$limit = 50;
$page  = max(1,(int)($_GET['page'] ?? 1));
$off   = ($page-1)*$limit;

$stmt = $pdo->prepare("
    SELECT
        p.code,
        p.used_by,
        u.username                              AS used_by_username,
        u.phone                                 AS used_by_phone,
        DATE_FORMAT(p.used_at,'%d.%m.%y %H:%i') AS used_at,
        p.segment_label
    FROM promo_codes p
    LEFT JOIN users u ON u.telegram_id = p.used_by
    WHERE p.used = 1
    ORDER BY p.used_at DESC
    LIMIT :lim OFFSET :off
");
$stmt->bindValue(':lim',$limit,PDO::PARAM_INT);
$stmt->bindValue(':off',$off ,PDO::PARAM_INT);
$stmt->execute();

$rows    = $stmt->fetchAll(PDO::FETCH_ASSOC);
$hasMore = count($rows) === $limit;

header('Content-Type: application/json');
echo json_encode(['rows'=>$rows,'hasMore'=>$hasMore]);
