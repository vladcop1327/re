<?php
require '../config.php';
header('Content-Type: application/json');

/*
 * GET page – номер страницы (1…)
 * GET q    – TG-ID начинается с…  (опционально)
 * ────────────────────────────────
 * {
 *   rows:[{
 *      telegram_id,
 *      username,
 *      phone,
 *      wrong_attempts,
 *      banned_until,
 *      codes:[{code,segment_label,used_at}, …]
 *   }, …],
 *   hasMore:true|false
 * }
 */

$limit = 50;
$page  = max(1,(int)($_GET['page'] ?? 1));
$off   = ($page-1)*$limit;

$q       = trim($_GET['q'] ?? '');
$params  = [];

$sql = "
  SELECT telegram_id, username, phone, wrong_attempts, banned_until
  FROM users
";
if($q!==''){
    $sql      .= " WHERE telegram_id LIKE :q";
    $params[':q']=$q.'%';
}
$sql .= " ORDER BY telegram_id DESC LIMIT :lim OFFSET :off";

$stmt=$pdo->prepare($sql);
$stmt->bindValue(':lim',$limit,PDO::PARAM_INT);
$stmt->bindValue(':off',$off ,PDO::PARAM_INT);
foreach($params as $k=>$v) $stmt->bindValue($k,$v);
$stmt->execute();

$rows=$stmt->fetchAll(PDO::FETCH_ASSOC);
if(!$rows){
    echo json_encode(['rows'=>[], 'hasMore'=>false]);
    exit;
}

/* ------ подтаскиваем использованные коды ------ */
$ids = implode(',',array_column($rows,'telegram_id'));
$codes=$pdo->query("
  SELECT
      used_by                        AS tg,
      code,
      segment_label,
      DATE_FORMAT(used_at,'%d.%m.%y %H:%i') AS used_at
  FROM promo_codes
  WHERE used=1 AND used_by IN ($ids)
")->fetchAll(PDO::FETCH_ASSOC);

$byUser=[];
foreach($codes as $c) $byUser[$c['tg']][]=$c;

foreach($rows as &$u) $u['codes']=$byUser[$u['telegram_id']]??[];

echo json_encode([
    'rows'   =>$rows,
    'hasMore'=>count($rows)===$limit
]);
