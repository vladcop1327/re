<?php
require '../config.php';

/*
 * GET  filter = all | used | unused
 * GET  page   = 1 … N
 * ────────────────────────────────
 * {
 *   rows:[{
 *      code,
 *      used,
 *      used_by,           // TG-ID
 *      used_by_username,  // @username  | null
 *      used_by_phone      // +7999…     | null
 *   }, …],
 *   hasMore:true|false
 * }
 */

$filter = $_GET['filter'] ?? 'all';
$page   = max(1,(int)($_GET['page'] ?? 1));
$limit  = 50;
$off    = ($page-1)*$limit;

$where = '';
if     ($filter==='used')   $where='WHERE p.used = 1';
elseif ($filter==='unused') $where='WHERE p.used = 0';

$sql = "
  SELECT
      p.code,
      p.used,
      IFNULL(p.used_by,'')            AS used_by,
      u.username                      AS used_by_username,
      u.phone                         AS used_by_phone
  FROM promo_codes p
  LEFT JOIN users u ON u.telegram_id = p.used_by
  $where
  ORDER BY p.id DESC
  LIMIT :lim OFFSET :off
";
$stmt=$pdo->prepare($sql);
$stmt->bindValue(':lim',$limit,PDO::PARAM_INT);
$stmt->bindValue(':off',$off ,PDO::PARAM_INT);
$stmt->execute();

$rows    = $stmt->fetchAll(PDO::FETCH_ASSOC);
$hasMore = count($rows)===$limit;

header('Content-Type: application/json');
echo json_encode(['rows'=>$rows,'hasMore'=>$hasMore]);